import numpy as np
from numpy.linalg import inv
from pymoo.algorithms.moo.nsga3 import NSGA3, get_extreme_points_c, get_nadir_point, \
    associate_to_niches, calc_niche_count, niching, comp_by_cv_then_random
from pymoo.docs import parse_doc_string
from pymoo.core.survival import Survival
from pymoo.operators.crossover.sbx import SimulatedBinaryCrossover
from pymoo.operators.mutation.pm import PolynomialMutation
from pymoo.operators.sampling.rnd import FloatRandomSampling
from pymoo.operators.selection.tournament import TournamentSelection
from pymoo.util.misc import intersect
from pymoo.util.nds.non_dominated_sorting import NonDominatedSorting
from pymoo.util.normalization import denormalize
from pymoo.util.reference_direction import UniformReferenceDirectionFactory
from pymoo.core.population import Population
import time
# =========================================================================================================
# Implementation
# =========================================================================================================


class rnsga3_hybrid(NSGA3):

    def __init__(self,
                 ref_points,
                 pop_per_ref_point,
                 mu=0.05,
                 sampling=FloatRandomSampling(),
                 selection=TournamentSelection(func_comp=comp_by_cv_then_random),
                 crossover=SimulatedBinaryCrossover(eta=30, prob=1.0),
                 mutation=PolynomialMutation(eta=20, prob=None),
                 eliminate_duplicates=True,
                 n_offsprings=None,
                 **kwargs):
        """

        Parameters
        ----------

        ref_points : {ref_points}
        pop_per_ref_point : int
            Size of the population used for each reference point.

        mu : float
            Defines the scaling of the reference lines used during survival selection. Increasing mu will result
            having solutions with a larger spread.

        Other Parameters
        -------

        n_offsprings : {n_offsprings}
        sampling : {sampling}
        selection : {selection}
        crossover : {crossover}
        mutation : {mutation}
        eliminate_duplicates : {eliminate_duplicates}

        """
        # number of objectives the reference lines have
        n_obj = ref_points.shape[1]

        # add the aspiration point lines
        aspiration_ref_dirs = UniformReferenceDirectionFactory(n_dim=n_obj, n_points=pop_per_ref_point).do()

        survival = AspirationPointSurvival(ref_points, aspiration_ref_dirs, mu=mu)
        pop_size = ref_points.shape[0] * aspiration_ref_dirs.shape[0] + aspiration_ref_dirs.shape[1]
        ref_dirs = None

        super().__init__(ref_dirs,
                         pop_size=pop_size,
                         sampling=sampling,
                         selection=selection,
                         crossover=crossover,
                         mutation=mutation,
                         survival=survival,
                         eliminate_duplicates=eliminate_duplicates,
                         n_offsprings=n_offsprings,
                         **kwargs)

    def _solve(self, problem):
        print('sooolve')
        if self.survival.ref_points.shape[1] != problem.n_obj:
            raise Exception("Dimensionality of reference points must be equal to the number of objectives: %s != %s" %
                            (self.survival.ref_points.shape[1], problem.n_obj))

        return super()._solve(problem)

    def _finalize(self):
        pass


class AspirationPointSurvival(Survival):

    def __init__(self, ref_points, aspiration_ref_dirs, mu=0.1):
        super().__init__()
        print('hohoooh')
        self.ref_points = ref_points
        self.aspiration_ref_dirs = aspiration_ref_dirs
        self.mu = mu

        self.ref_dirs = aspiration_ref_dirs
        self.extreme_points = None
        self.intercepts = None
        self.nadir_point = None
        self.opt = None
        self.ideal_point = np.full(ref_points.shape[1], np.inf)
        self.worst_point = np.full(ref_points.shape[1], -np.inf)

    def _do(self, problem, pop, n_survive, D=None, **kwargs):



        F = pop.get("F")

        for i in range(0,len(pop)):
              pop[i].TradeOff=0

        # find or usually update the new ideal point - from feasible solutions
        self.ideal_point = np.min(np.vstack((self.ideal_point, F, self.ref_points)), axis=0)
        self.worst_point = np.max(np.vstack((self.worst_point, F, self.ref_points)), axis=0)

        # calculate the fronts of the population
        fronts, rank = NonDominatedSorting().do(F, return_rank=True, n_stop_if_ranked=n_survive)
        non_dominated, last_front = fronts[0], fronts[-1]

        # find the extreme points for normalization
        self.extreme_points = get_extreme_points_c(
            np.vstack([F[non_dominated], self.ref_points])
            , self.ideal_point,
            extreme_points=self.extreme_points)

        # find the intercepts for normalization and do backup if gaussian elimination fails
        worst_of_population = np.max(F, axis=0)
        worst_of_front = np.max(F[non_dominated, :], axis=0)

        self.nadir_point = get_nadir_point(self.extreme_points, self.ideal_point, self.worst_point,
                                           worst_of_population, worst_of_front)

        #  consider only the population until we come to the splitting front
        I = np.concatenate(fronts)
        pop, rank, F = pop[I], rank[I], F[I]
        #print('begin CalcTradeOff')
        #print('pop before ',pop[0].TradeOff)
        counter = 0
        for i in range(len(fronts)):
            for j in range(len(fronts[i])):
                fronts[i][j] = counter
                counter += 1
        print('front counter',counter)
        last_front = fronts[-1]
        unit_ref_points = (self.ref_points - self.ideal_point) / (self.nadir_point - self.ideal_point)
        ref_dirs = get_ref_dirs_from_points(unit_ref_points, self.aspiration_ref_dirs, mu=self.mu)
        self.ref_dirs = denormalize(ref_dirs, self.ideal_point, self.nadir_point)

        # associate individuals to niches
        niche_of_individuals, dist_to_niche, dist_matrix = associate_to_niches(F, ref_dirs, self.ideal_point, self.nadir_point)

        pop.set('rank', rank, 'niche', niche_of_individuals, 'dist_to_niche', dist_to_niche)

        # set the optimum, first front and closest to all reference directions
        closest = np.unique(dist_matrix[:, np.unique(niche_of_individuals)].argmin(axis=0))
        self.opt = pop[intersect(fronts[0], closest)]

        # if we need to select individuals to survive
        if len(pop) > n_survive:

            # if there is only one front
            if len(fronts) == 1:
                n_remaining = n_survive
                until_last_front = np.array([], dtype=np.int)
                niche_count = np.zeros(len(ref_dirs), dtype=np.int)

            # if some individuals already survived
            else:
                until_last_front = np.concatenate(fronts[:-1])
                niche_count = calc_niche_count(len(ref_dirs), niche_of_individuals[until_last_front])
                n_remaining = n_survive - len(until_last_front)

            S = niching(pop[last_front], n_remaining, niche_count, niche_of_individuals[last_front], dist_to_niche[last_front])

            survivors = np.concatenate((until_last_front, last_front[S].tolist()))
            pop = pop[survivors]


        """
        my modifs
        """
        print('craaap')
        # attributes to be set after the survival
        print('pop before tradoff : ',len(pop))
        for elem in range(0, len(pop)):
            print(pop[elem].TradeOff)
        pop_tradeof = CalcTradeOff(pop, pop.get("F"), 0.05, 0.1)
        # print("type(pop)", type(pop))
        #        pop_tradeof.sort(key=lambda x: x.TradeOff, reverse=True)
        # sorted_pop = sorted(pop_tradeof, key=lambda x: x.TradeOff)
        # print('population before sorting')
        for i in range(0, len(pop_tradeof)):
            print('elem ', i, 'has trdoff', pop_tradeof[i].TradeOff)
        X__ = sorted(range(len(pop_tradeof)), key=lambda k: pop_tradeof[k].TradeOff,reverse= False )

        print('Big X', X__)
        pop_tradeof_to_sort = pop_tradeof.copy()
        for elem in range(0, len(X__)):
            pop_tradeof_to_sort[elem] = pop_tradeof[X__[elem]]
        # for elem in range (0, len(X__)):
        #    pop_tradeof[elem] = -1
        sorted_pop = pop_tradeof_to_sort.copy()
        # sorted_pop = sorted(pop_tradeof, key=lambda x: x.TradeOff)
        # print("type(sorted_pop)", type(sorted_pop))
        # print('pop after',sorted_pop)
        # print('population after sorting')
        XP = sorted_pop
        # for i in range(0,len(XP)):
        #      print('elem ',i,'has trdoff',XP[i].TradeOff)
        # print('END CalcTradeOff')
        # print('pop_tradeof',pop_tradeof)
        # print('pop_tradeof.get("F")',pop_tradeof.get("F"))
        # print('pop_tradeof.get("X")',pop_tradeof.get("X"))
        # update the front indices for the current population

        pop_max = len(sorted_pop) if len(sorted_pop) < 500 else 500
        pop_before_delete = Population(pop_max)

        for elem in range(0, pop_max):
            pop_before_delete[elem] = sorted_pop[elem]

        pop = pop_before_delete.copy()
        print('pop after tradoff : ',len(pop))
        for elem in range(0, len(pop)):
            print(pop[elem].TradeOff)


        return pop




def get_ref_dirs_from_points(ref_point, ref_dirs, mu=0.1):
    """
    This function takes user specified reference points, and creates smaller sets of equidistant
    Das-Dennis points around the projection of user points on the Das-Dennis hyperplane
    :param ref_point: List of user specified reference points
    :param n_obj: Number of objectives to consider
    :param mu: Shrinkage factor (0-1), Smaller = tigher convergence, Larger= larger convergence
    :return: Set of reference points
    """

    n_obj = ref_point.shape[1]

    val = []
    n_vector = np.ones(n_obj) / np.sqrt(n_obj)  # Normal vector of Das Dennis plane
    point_on_plane = np.eye(n_obj)[0]  # Point on Das-Dennis

    for point in ref_point:

        ref_dir_for_aspiration_point = np.copy(ref_dirs)  # Copy of computed reference directions
        ref_dir_for_aspiration_point = mu * ref_dir_for_aspiration_point

        cent = np.mean(ref_dir_for_aspiration_point, axis=0)  # Find centroid of shrunken reference points

        # Project shrunken Das-Dennis points back onto original Das-Dennis hyperplane
        intercept = line_plane_intersection(np.zeros(n_obj), point, point_on_plane, n_vector)
        shift = intercept - cent  # shift vector

        ref_dir_for_aspiration_point += shift

        # If reference directions are located outside of first octant, redefine points onto the border
        if not (ref_dir_for_aspiration_point > 0).min():
            ref_dir_for_aspiration_point[ref_dir_for_aspiration_point < 0] = 0
            ref_dir_for_aspiration_point = ref_dir_for_aspiration_point / np.sum(ref_dir_for_aspiration_point, axis=1)[
                                                                          :, None]
        val.extend(ref_dir_for_aspiration_point)

    val.extend(np.eye(n_obj))  # Add extreme points
    return np.array(val)


# intersection function
def CalcTradeOff (pop ,F , trade , spacer ):
# Initialisation
    # we give F as pop
    # we give fronts as F

    n= len ( pop )
    for i in range(1, n):
        #  pop (i) .TradeOff =0
        pop[i].TradeOff= 0
    # Normalisation of objectives
    Cost_before_inv =pop.get("F")
    print('Cost_before_inv :  \n')
    for i in Cost_before_inv :
        print(i)
    x = np.array(Cost_before_inv)
    #print('x',x)
    to_inverse_inside =np.zeros((len(Cost_before_inv[0]),len(Cost_before_inv)))
    start_time = time.time()
    for d in range(0, len(Cost_before_inv[0])):
        for s in range(0, len(Cost_before_inv)):
            to_inverse_inside[d,s] = x[s,d]

    for i in to_inverse_inside :
        print(i)
    print("--- %s seconds first loop ---" % (time.time() - start_time))
    Cost = to_inverse_inside
    M= len (Cost_before_inv[0])
    CostSorted = np.zeros((M ,n))
    IndexSorted = np.zeros((M ,n))
    Index = np.r_[:n]+1
    Minima = np.zeros ((M ,1))
    Maxima = np.zeros ((M ,1))
    Range = np.zeros ((M ,1))
    start_time = time.time()

#TODO
    for i in range (0,M):
        #[CostSorted[i,], ]= sort( )
        to_sort = Cost[i,]
        X = sorted(range(len(to_sort)), key=lambda k: to_sort[k])
        IndexSorted[i,] = X
        CostSorted[i,] = to_sort[X]
        """
             To check aswell, the fucntion sorted in here we dont know what ois exactly doing
             it seems like it is nit doing what ist should do exactly :
             [CostSorted(i ,:),IndexSorted(i ,:)]= sort(Cost(i ,:));

        """
        Minima[i] = CostSorted[i][0]
        Maxima[i] = CostSorted[i][n-1]
        Range[i] = abs(Maxima[i] - Minima[i])
    #print('Cost before ',Cost)


    print("--- %s seconds minima and maxima loop---" % (time.time() - start_time))
    start_time = time.time()
    for i in range(0, M):
        for j in range(0, n):
            if Range[i] == 0:
                Range[i] = 1
            Cost [i ][j] =( Cost [i] [j] - Minima [i])/ Range [i]


    print("--- %s seconds ---" % (time.time() - start_time))
    #print('Cost After',Cost)
    # Trade -off calculation
    k= len (to_inverse_inside)
    #F= to_inverse_inside

    fronts, rank = NonDominatedSorting().do(Cost_before_inv, return_rank=True)
    #print('fronts, rank',fronts, rank)
    F = fronts[0]



    for i in range(0, k): # for all non -dominated fronts
        #print()
        #print('F', F)
        #print('Cost', Cost)
        Front_Cost = Cost [: ,F] # select needed costs
        #print('(Cost [: ,F]',Cost [: ,F])
        Front_Index = F # repmat with indexes in pop of selected solutions
        start_time = time.time()
        for j in range (0, M):
            front_to_sort = Front_Cost[j,]
            Y = sorted(range(len(front_to_sort)), key=lambda k: front_to_sort[k])
            """
            the question is if the sorted fuction is doing exactly what the 
            functon sort is doing in Matlab [:,Sorter ]= sort(Front_Cost(j ,:));
             
            """

            Index_sorted_acc = Front_Index [Y]
            Front_cost_sorted_obj = Front_Cost [: , Y ]
            # for a solution in that front
            k_front = len(F)
            start_time = time.time()
            for l in range(0, k_front):
                iterleft = 0
                iterright = 0
                while l - iterright > 0:
                    A = abs(Front_cost_sorted_obj[:, l] - Front_cost_sorted_obj[:, l - iterright])
                    if any(A < trade) or A(j) < spacer:
                    #    print('pop',pop)
                    #    print('Index_sorted_acc(l)',Index_sorted_acc[l])
                        pop[Index_sorted_acc[l]].TradeOff = pop[Index_sorted_acc[l]].TradeOff + 1
                    iterright = iterright + 1
                while l + iterleft < k_front:
                 #   print('l + iterleft',l + iterleft,'k_front',k_front)
                    A = abs(Front_cost_sorted_obj[:, l] - Front_cost_sorted_obj[:, l + iterleft])
                    if any(A < trade) or A(j) < spacer:
                        pop[Index_sorted_acc[l]].TradeOff = pop[Index_sorted_acc[l]].TradeOff + 1
                    iterleft = iterleft + 1
            print("--- %s seconds inner loop ---" % (time.time() - start_time))
        print("--- %s seconds outer loop ---" % (time.time() - start_time))
    return pop


def line_plane_intersection(l0, l1, p0, p_no, epsilon=1e-6):
    """
    l0, l1: define the line
    p0, p_no: define the plane:
        p0 is a point on the plane (plane coordinate).
        p_no is a normal vector defining the plane direction;
             (does not need to be normalized).

    reference: https://en.wikipedia.org/wiki/Line%E2%80%93plane_intersection
    return a Vector or None (when the intersection can't be found).
    """

    l = l1 - l0
    dot = np.dot(l, p_no)

    if abs(dot) > epsilon:
        # the factor of the point between p0 -> p1 (0 - 1)
        # if 'fac' is between (0 - 1) the point intersects with the segment.
        # otherwise:
        #  < 0.0: behind p0.
        #  > 1.0: infront of p1.
        w = p0 - l0
        d = np.dot(w, p_no) / dot
        l = l * d
        return l0 + l
    else:
        # The segment is parallel to plane then return the perpendicular projection
        ref_proj = l1 - (np.dot(l1 - p0, p_no) * p_no)
        return ref_proj


parse_doc_string(rnsga3_hybrid.__init__)
