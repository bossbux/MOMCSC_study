import numpy as np
from pymoo.core.problem import Problem
from pymoo.core.algorithm import Algorithm
from pymoo.operators.mutation.pm import PolynomialMutation
from pymoo.operators.sampling.rnd import PermutationRandomSampling
from pymoo.operators.selection.rnd  import RandomSelection
from pymoo.util.display import Display
from pymoo.optimize import minimize


# Define your optimization problem
class MyProblem(Problem):
    def __init__(self):
        super().__init__(n_var=2, n_obj=2, n_constr=0, xl=np.array([0, 0]), xu=np.array([1, 1]))

    def _evaluate(self, x, out, *args, **kwargs):
        f1 = x[0]
        f2 = (1 + x[1]) / x[0]
        out["F"] = [f1, f2]

# Define your NSPSO algorithm
class NSPSO(Algorithm):
    def non_dominated_sorting(F):
        num_individuals = len(F)
        dominated_count = [0] * num_individuals
        dominated_by = [[] for _ in range(num_individuals)]
        fronts = []

        for i in range(num_individuals):
            for j in range(num_individuals):
                if i != j:
                    if all(F[i] <= F[j]) and any(F[i] < F[j]):
                        dominated_count[j] += 1
                        dominated_by[i].append(j)

        while True:
            current_front = [i for i in range(num_individuals) if dominated_count[i] == 0]
            if not current_front:
                break
            for i in current_front:
                dominated_count[i] = -1
            fronts.append(current_front)
            for i in current_front:
                for j in dominated_by[i]:
                    dominated_count[j] -= 1

        return fronts
    def __init__(self, pop_size, max_gen):
        self.pop_size = pop_size
        self.max_gen = max_gen
        self.population = None
        super().__init__()

    def _initialize(self):
        sampling = PermutationRandomSampling()
        self.population = sampling.do(self.problem, self.pop_size)
        self.population = self.population.new("X", np.random.rand(self.pop_size, 2))
        self.population = self.population.new("F", np.full((self.pop_size, 2), np.inf))

    def _next(self):
        fronts = non_dominated_sorting(self.population.get("F"))

        for i, front in enumerate(fronts):
            for k in front:
                selected = RandomSelection().do(self.problem, self.population, self.pop_size)
                p_best = selected[np.argmin(selected.get("F")[:, 0])]

                # Update particle velocity
                r1, r2 = np.random.random(2)
                self.population[k, "V"] = (
                        self.inertia_weight * self.population[k, "V"]
                        + self.c1 * r1 * (self.population[k, "P"] - self.population[k, "X"])
                        + self.c2 * r2 * (p_best["P"] - self.population[k, "X"])
                )

                # Update particle position
                self.population[k, "X"] = self.population[k, "X"] + self.population[k, "V"]

                # Evaluate new position
                self.population[k].evaluate()

                # Update personal best
                if self.population[k, "F"][0] < self.population[k, "P"][0]:
                    self.population[k, "P"] = self.population[k, "X"]


problem = MyProblem()
algorithm = NSPSO(pop_size=100, max_gen=100)
res = minimize(problem, algorithm, seed=1, verbose=True)

# Display the results
Display().finalize(res)